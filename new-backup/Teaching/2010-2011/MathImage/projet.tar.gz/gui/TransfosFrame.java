package gui;

import java.awt.BorderLayout;
import java.awt.Toolkit;
import javax.swing.JFrame;
import javax.swing.JPanel;


/**
 * Main frame of the application. Contains the scene window and the control panel
 */
public class TransfosFrame extends JFrame {


	private static final long serialVersionUID = 1L;

	/** the graphic part of the display */
	protected TransfosView view;

	/** control panel */
	protected TransfosControls controls;

	public TransfosFrame() {
		super("Transfos 3D");
				
		view = new TransfosView();
		controls = new TransfosControls(this);

		JPanel mainPane = new JPanel(new BorderLayout());
		mainPane.add(view, BorderLayout.CENTER);
		mainPane.add(controls, BorderLayout.EAST);
	
		setContentPane(mainPane);
		pack();
		
		//position frame at the center of the screen
		int screenWidth = Toolkit.getDefaultToolkit().getScreenSize().width;
		int screenHeight = Toolkit.getDefaultToolkit().getScreenSize().height;
		int frameXpos = (screenWidth - this.getWidth()) / 2;
		int frameYpos = (screenHeight - this.getHeight()) / 2;
		this.setLocation(frameXpos, frameYpos);	
		
		
		setVisible(true);
	}
	
	/**
	 * static method to start an instance of the application
	 */
	public static void start() {
		javax.swing.SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				JFrame.setDefaultLookAndFeelDecorated(true);
				TransfosFrame cv = new TransfosFrame();
				cv.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			}
		});
	}
	
}
