package gui;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;


/**
 * Control panel class
 */
class TransfosControls extends JPanel {

	private final static int defaultJTextFieldwidth = 3;
	
	private static final long serialVersionUID = 1L;

	/**
	 * matrix fields
	 */
	private final JTextField m00 = new JTextField("1.0", defaultJTextFieldwidth);
	private final JTextField m01 = new JTextField("0.0", defaultJTextFieldwidth);
	private final JTextField m02 = new JTextField("0.0", defaultJTextFieldwidth);
	private final JTextField m03 = new JTextField("0.0", defaultJTextFieldwidth);	
	private final JTextField m10 = new JTextField("0.0", defaultJTextFieldwidth);
	private final JTextField m11 = new JTextField("1.0", defaultJTextFieldwidth);
	private final JTextField m12 = new JTextField("0.0", defaultJTextFieldwidth);
	private final JTextField m13 = new JTextField("0.0", defaultJTextFieldwidth);	
	private final JTextField m20 = new JTextField("0.0", defaultJTextFieldwidth);
	private final JTextField m21 = new JTextField("0.0", defaultJTextFieldwidth);
	private final JTextField m22 = new JTextField("1.0", defaultJTextFieldwidth);
	private final JTextField m23 = new JTextField("0.0", defaultJTextFieldwidth);	
	private final JTextField m30 = new JTextField("0.0", defaultJTextFieldwidth);
	private final JTextField m31 = new JTextField("0.0", defaultJTextFieldwidth);
	private final JTextField m32 = new JTextField("0.0", defaultJTextFieldwidth);
	private final JTextField m33 = new JTextField("1.0", defaultJTextFieldwidth);	

	TransfosControls(final TransfosFrame f) {
		super(new GridBagLayout());
		
		JPanel cameraPanel = cameraPanel(f);
		JPanel tPanel = transfoPanel(f);
		
		JButton reset = new JButton("Remise à zéro");
		//TODO : add actions to the button!
				
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.NONE;
        gbc.insets = new Insets(2, 2, 2, 2);
        
		gbc.gridx = gbc.gridy = 0;
		gbc.gridwidth = GridBagConstraints.REMAINDER;
		gbc.gridheight = 1;
		add(cameraPanel, gbc);
		
		gbc.insets = new Insets(30, 2, 30, 2);
		gbc.gridy = 1;
		add(reset, gbc);		
		
		gbc.insets = new Insets(30, 2, 2, 2);
		gbc.gridy = 2;
		add(tPanel, gbc);
		
		//to make the fields accept only numbers
		makeDoubleJTextfield(m00);
		makeDoubleJTextfield(m01);		
		makeDoubleJTextfield(m02);
		makeDoubleJTextfield(m03);		
		makeDoubleJTextfield(m10);
		makeDoubleJTextfield(m11);		
		makeDoubleJTextfield(m12);
		makeDoubleJTextfield(m13);		
		makeDoubleJTextfield(m20);
		makeDoubleJTextfield(m21);		
		makeDoubleJTextfield(m22);
		makeDoubleJTextfield(m23);		
		makeDoubleJTextfield(m30);
		makeDoubleJTextfield(m31);		
		makeDoubleJTextfield(m32);
		makeDoubleJTextfield(m33);			
	}
	
	
	/**
	 * to build the solid transformation panel
	 */
	JPanel transfoPanel(final TransfosFrame f){
		GridBagLayout gbl = new GridBagLayout();
		JPanel tPanel = new JPanel(gbl);
	
		JLabel title = new JLabel("Transformation de la figure (A = appliquer, C = composer, R = remplacer)");
		
		
		//TODO : add actions to the buttons!
		
		//MATRIX buttons
		
		JLabel matLabel = new JLabel("Matrice : ");		
				
		JButton applyMatrix = new JButton("A");

		
		//HOMOTHETY BUTTONS
		
		JLabel hom = new JLabel("Homothétie de rapport");
		final JTextField homTF = new JTextField("2.0", defaultJTextFieldwidth);
		makeDoubleJTextfield(homTF);
		
		JButton homR = new JButton("R");

		JButton homC = new JButton("C");

		JButton homA = new JButton("A");

		
		//ROTATION BUTTONS
		
		JLabel rot = new JLabel("Rotation d'angle");
		final JTextField rotTFangle = new JTextField("0.25", defaultJTextFieldwidth);
		makeDoubleJTextfield(rotTFangle);
		JLabel rot2 = new JLabel("*PI autour de l'axe");
		final String[] axisList = {"X", "Y", "Z"};
		final JComboBox rotCBaxis = new JComboBox(axisList);
		
		JButton rotR = new JButton("R");

		JButton rotC = new JButton("C");	

		JButton rotA = new JButton("A");

		
		//PROJECTION BUTTONS
		
		JLabel proj = new JLabel("Projection sur le plan");
		final String[] planesList = {"x=0", "y=0", "z=0"};
		final JComboBox projCB = new JComboBox(planesList);
		
		JButton projR = new JButton("R");

		JButton projC = new JButton("C");

		JButton projA = new JButton("A");
		
		
		//TRANSLATION BUTTONS
		
		JLabel trans = new JLabel("Translation de vecteur");
		final JTextField transX = new JTextField("1.0", defaultJTextFieldwidth);
		makeDoubleJTextfield(transX);
		final JTextField transY = new JTextField("1.0", defaultJTextFieldwidth);
		makeDoubleJTextfield(transY);
		final JTextField transZ = new JTextField("1.0", defaultJTextFieldwidth);
		makeDoubleJTextfield(transZ);
		
		JButton transR = new JButton("R");

		JButton transC = new JButton("C");

		JButton transA = new JButton("A");
		
		
		//POSITION ALL BUTTONS		
		
		JPanel transPanel = new JPanel(new GridBagLayout());
		GridBagConstraints ct = new GridBagConstraints();
		ct.fill = GridBagConstraints.NONE;
        ct.insets = new Insets(1, 1, 1, 1);
		ct.gridx = ct.gridy = 0;
		ct.gridheight = ct.gridwidth = 1;
		transPanel.add(transX, ct);
		ct.gridx++;
		transPanel.add(transY, ct);
		ct.gridx++;
		ct.gridwidth = GridBagConstraints.REMAINDER;
		ct.gridheight = GridBagConstraints.REMAINDER;
		transPanel.add(transZ, ct);
		
		JPanel matrixPanel = new JPanel(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();
		c.fill = GridBagConstraints.NONE;
        c.insets = new Insets(1, 1, 1, 1);
		c.gridx = c.gridy = 0;
		c.gridheight = c.gridwidth = 1;
		matrixPanel.add(m00, c);
		c.gridx++;
		matrixPanel.add(m01, c);
		c.gridx++;
		matrixPanel.add(m02, c);	
		c.gridx++;
		c.gridwidth = GridBagConstraints.REMAINDER;
		matrixPanel.add(m03, c);
		
		c.gridwidth = 1;
		c.gridy = 1;
		c.gridx = 0;
		matrixPanel.add(m10, c);
		c.gridx++;
		matrixPanel.add(m11, c);	
		c.gridx++;
		matrixPanel.add(m12, c);
		c.gridx++;
		c.gridwidth = GridBagConstraints.REMAINDER;
		matrixPanel.add(m13, c);
		
		c.gridy = 2;
		c.gridx = 0;
		c.gridwidth = 1;
		matrixPanel.add(m20, c);
		c.gridx++;
		matrixPanel.add(m21, c);
		c.gridx++;
		matrixPanel.add(m22, c);	
		c.gridx++;
		c.gridwidth = GridBagConstraints.REMAINDER;
		matrixPanel.add(m23, c);
		
		c.gridy = 3;
		c.gridx = 0;
		c.gridwidth = 1;
		matrixPanel.add(m30, c);
		c.gridx++;
		matrixPanel.add(m31, c);
		c.gridx++;
		matrixPanel.add(m32, c);	
		c.gridx++;
		c.gridwidth = GridBagConstraints.REMAINDER;
		c.gridheight = GridBagConstraints.REMAINDER;
		matrixPanel.add(m33, c);
		
		
		
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.NONE;
        gbc.insets = new Insets(2, 2, 2, 2);
		
		gbc.gridx = gbc.gridy = 0;
		gbc.gridwidth = GridBagConstraints.REMAINDER;
		gbc.gridheight = 1;
		tPanel.add(title, gbc);
		
		//matrix
		gbc.gridy = 1;
		gbc.gridx = 0;
		gbc.gridwidth = 1;	
		tPanel.add(matLabel,gbc);
		gbc.gridx = 1;
		gbc.gridwidth = 6;
		tPanel.add(matrixPanel, gbc);
		gbc.gridx = 7;	
		gbc.gridwidth = GridBagConstraints.REMAINDER;
		tPanel.add(applyMatrix);
		

		//homothetie
		gbc.gridy = 2;
		gbc.gridx = 0;		
		gbc.gridwidth = 1;
		tPanel.add(hom, gbc);
		gbc.gridx++;
		tPanel.add(homTF, gbc);
		gbc.gridx = 7;
		tPanel.add(homA, gbc);
		gbc.gridx++;
		tPanel.add(homC, gbc);
		gbc.gridx++;
		gbc.gridwidth = GridBagConstraints.REMAINDER;
		tPanel.add(homR, gbc);		
		
		//rotation		
		gbc.gridy = 3;
		gbc.gridx = 0;
		gbc.gridwidth = 1;
		tPanel.add(rot, gbc);
		gbc.gridx++;
		tPanel.add(rotTFangle, gbc);	
		gbc.gridx++;
		tPanel.add(rot2, gbc);	
		gbc.gridx++;
		tPanel.add(rotCBaxis, gbc);
		gbc.gridx = 7;
		tPanel.add(rotA, gbc);	
		gbc.gridx++;
		tPanel.add(rotC, gbc);
		gbc.gridx++;
		gbc.gridwidth = GridBagConstraints.REMAINDER;
		tPanel.add(rotR, gbc);

		//projection
		gbc.gridy = 4;
		gbc.gridx = 0;		
		gbc.gridwidth = 1;
		tPanel.add(proj, gbc);
		gbc.gridx++;
		tPanel.add(projCB, gbc);
		gbc.gridx = 7;
		tPanel.add(projA, gbc);
		gbc.gridx++;
		tPanel.add(projC, gbc);
		gbc.gridx++;
		gbc.gridwidth = GridBagConstraints.REMAINDER;
		tPanel.add(projR, gbc);
		
		//translation
		gbc.gridy = 5;
		gbc.gridx = 0;		
		gbc.gridwidth = 1;
		tPanel.add(trans, gbc);
		gbc.gridx++;
		tPanel.add(transPanel, gbc);		
		gbc.gridx = 7;
		tPanel.add(transA, gbc);
		gbc.gridx++;
		tPanel.add(transC, gbc);
		gbc.gridx++;
		gbc.gridwidth = GridBagConstraints.REMAINDER;
		gbc.gridheight = GridBagConstraints.REMAINDER;
		tPanel.add(transR, gbc);	
		
		
		return tPanel;
	}
	
	
	/**
	 * to build the camera control panel
	 */
	JPanel cameraPanel(final TransfosFrame f){
		GridBagLayout gbl = new GridBagLayout();
		JPanel cameraPanel = new JPanel(gbl);
		
		//TODO : add actions to the buttons!
		
		JButton zIn = new JButton("+");

		JButton zOut = new JButton("-");

		JButton rotateLeft = new JButton("<-");

		JButton rotateRight = new JButton("->");

		JButton rotateUp = new JButton("^");

		JButton rotateDown = new JButton("v");

		JButton rotateLeftZ = new JButton("<-\\");

		JButton rotateRightZ = new JButton("/->");

		JButton translateLeft = new JButton("<");

		JButton translateRight = new JButton(">");

		JButton translateUp = new JButton("^");

		JButton translateDown = new JButton("v");
		
		
		JLabel zoomLabel = new JLabel("Zoom caméra");
		JLabel rotLabel = new JLabel("Rotation caméra");
		JLabel transLabel = new JLabel("Translation caméra");
		
		
		//POSITION ALL BUTTONS
		
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.NONE;
        gbc.insets = new Insets(2, 2, 2, 2);
        
		gbc.gridx = gbc.gridy = 0;
		gbc.gridwidth = gbc.gridheight = 1;		
		cameraPanel.add(zoomLabel, gbc);
		
		gbc.gridx = 1;
		gbc.gridwidth = 5;
		cameraPanel.add(rotLabel, gbc);
		gbc.gridx = 7;
		cameraPanel.add(transLabel, gbc);
		
		gbc.gridy = 1;
		gbc.gridx = 0;
		gbc.gridwidth = 1;
		cameraPanel.add(zIn, gbc);
		
		gbc.gridx = 3;
		cameraPanel.add(rotateUp, gbc);
		
		gbc.gridx = 8;
		cameraPanel.add(translateUp, gbc);

		gbc.gridy = 2;
		gbc.gridwidth = 1;
		gbc.gridx = 0;
		cameraPanel.add(zOut, gbc);
		
		gbc.gridx = 1;
		gbc.gridwidth = 1;
		cameraPanel.add(rotateLeftZ, gbc);
		
		gbc.gridx = 2;
		cameraPanel.add(rotateLeft, gbc);
		
		gbc.gridx = 4;
		gbc.gridwidth = 1;
		cameraPanel.add(rotateRight, gbc);
		
		gbc.gridx = 5;
		cameraPanel.add(rotateRightZ, gbc);

		gbc.gridx = 7;
		cameraPanel.add(translateLeft, gbc);
				
		gbc.gridx = 9;
		cameraPanel.add(translateRight, gbc);

		gbc.gridy = 3;
		gbc.gridx = 3;
		cameraPanel.add(rotateDown, gbc);		
		
		gbc.gridx = 8;
		cameraPanel.add(translateDown, gbc);

		return cameraPanel;
	}
	
	/**
	 * make sure JTextField only accepts valid "double" text
	 */
	private void makeDoubleJTextfield(final JTextField j){
		j.addKeyListener(new KeyListener(){
			public void keyPressed(KeyEvent arg0) {
			}
			public void keyReleased(KeyEvent arg0) {
				try{
					Double.parseDouble(j.getText());
				}
				catch(NumberFormatException e){
					char c = arg0.getKeyChar();
					char[] ct = {c};
					StringBuffer s = new StringBuffer(j.getText());
					s.deleteCharAt(s.indexOf(new String(ct)));
					j.setText(s.toString());
				}
			}
			public void keyTyped(KeyEvent arg0) {
			}
		});
	}

}

