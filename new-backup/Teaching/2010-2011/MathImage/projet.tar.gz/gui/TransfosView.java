package gui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;

import javax.swing.JComponent;

/**
 * the viewing window of the geometric figures
 */
class TransfosView extends JComponent {


	private static final long serialVersionUID = -5215225680410825565L;
	
	/**
	 * default window dimensions
	 */
	private static final int defaultWindowHeight = 600;
	private static final int defaultWindowWidth = 600;
	
	

	
	TransfosView() {
		setPreferredSize(new Dimension(defaultWindowWidth, defaultWindowHeight));
		setOpaque(true);
		setBackground(Color.LIGHT_GRAY.brighter());
		setForeground(Color.red);
				
		

	}


	
	
	protected void paintComponent(Graphics g) {
		
		int width = getWidth();

		// Paint background if we're opaque.
		if (isOpaque()) {
			g.setColor(getBackground());
			g.fillRect(0, 0, width, getHeight());
		}

		g.setColor(getForeground());
		

	}
		
	
}
