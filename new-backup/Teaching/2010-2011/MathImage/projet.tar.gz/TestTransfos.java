import gui.TransfosFrame;


public class TestTransfos {
	public static void main(String[] args){
		TransfosFrame.start();
	}
}
