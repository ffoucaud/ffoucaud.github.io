import java.awt.BorderLayout;

import javax.swing.JFrame;


public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Thermo t = new Thermo(10);
		Slide s = new Slide(t);
		Text txt = new Text(t);
		JFrame f = new JFrame("thermo");
		f.setLayout(new BorderLayout());
		f.add(s, BorderLayout.EAST);
		f.add(txt, BorderLayout.WEST);
		f.pack();
		f.setVisible(true);
		
		

	}

}
