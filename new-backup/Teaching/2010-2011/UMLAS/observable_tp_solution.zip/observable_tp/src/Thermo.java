import java.util.Observable;


public class Thermo extends Observable{

	private int temp_Celsius = 0;

	public Thermo(int temp){
		this.setTemp_Celsius(temp);		
	}
	
	public void setTemp_Celsius(int temp_Celsius) {
		this.temp_Celsius = temp_Celsius;
		System.out.println("temp mod at " + temp_Celsius + "\n");
		this.setChanged();
		this.notifyObservers();
	}

	public int getTemp_Celsius() {
		return temp_Celsius;
	}
	
}
