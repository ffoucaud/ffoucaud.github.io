import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Observable;
import java.util.Observer;

import javax.swing.JPanel;
import javax.swing.JTextField;


public class Text extends JPanel implements Observer {
	private static final long serialVersionUID = -548707599384083762L;

	private JTextField field;
	
	private Thermo thermo;
	
	public Text(final Thermo t){
		super(new BorderLayout());
		this.thermo = t;
		this.thermo.addObserver(this);
		field = new JTextField(thermo.getTemp_Celsius());
		field.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				Integer thermoTemp = new Integer(t.getTemp_Celsius());
				Integer fieldTemp = Integer.parseInt(field.getText());
				if(!fieldTemp.equals(thermoTemp.toString()))
					t.setTemp_Celsius(fieldTemp);
				
			}
		});
		this.add(field);
		
	}
	
	
	@Override
	public void update(Observable o, Object arg) {
		System.out.println("update txt\n");
		Integer thermoTemp = new Integer(((Thermo)o).getTemp_Celsius());
		if(!field.getText().equals(thermoTemp.toString()))
			field.setText(thermoTemp.toString());

	}

}
