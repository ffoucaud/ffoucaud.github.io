import java.awt.BorderLayout;
import java.util.Observable;
import java.util.Observer;

import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;


public class Slide extends JPanel implements Observer {
	private static final long serialVersionUID = 8477466688641926299L;

	private JSlider slider;
	Thermo thermo;
	
	public Slide(Thermo t){
		super(new BorderLayout());
		this.thermo = t;
		this.thermo.addObserver(this);
		
		slider = new JSlider(-70,70);
		slider.setValue(0);
		slider.setOrientation(JSlider.VERTICAL);
		slider.setMajorTickSpacing(10);
		slider.setMinorTickSpacing(1);
		slider.setPaintLabels(true);
		slider.setPaintTicks(true);
		//slider.setPaintTrack(true);
		this.add(slider);
		this.setVisible(true);
		slider.addChangeListener(new ChangeListener() {		
			@Override
			public void stateChanged(ChangeEvent e) {
				thermo.setTemp_Celsius(slider.getValue());
			}
		});
	}
	
	@Override
	public void update(Observable o, Object arg) {
		System.out.println("update\n");
		int thermoTemp = ((Thermo)o).getTemp_Celsius();
		if(slider.getValue() != thermoTemp)
		slider.setValue(thermoTemp);
	}
	
	

}
