import java.net.*;
import java.io.*;

/**
 * Thread associé à chaque nouveau client. Pour "threader", il est nécessaire
 * d'implementer l'interface Runnable (il existe une autre solution).
 */
class HandleClientThread implements Runnable {
	private Thread t; /* Thread propre à un client */
	private Socket s; /* Socket associée à un client */
	private PrintWriter out; /* Flux de sortie du client */
	private BufferedReader in; /* Flux en entrée du client */
	private ServerExample serv; /* Référence vers le serveur principale */
	private int idClient = 0; /* Numéro du client */

	/**
	 * Constructeur appelé lorque le serveur principale accepte une connexion
	 * d'un client.
	 * 
	 * @param ms
	 * @param mserv
	 */
	HandleClientThread(Socket ms, ServerExample mserv) {
		serv = mserv;
		s = ms;

		try {
			/**
			 * Instanciation des flux d'entrées et de sortie depuis la socket.
			 */
			out = new PrintWriter(s.getOutputStream());
			in = new BufferedReader(new InputStreamReader(s.getInputStream()));

			/**
			 * Ajout du flux en sortie à la liste des flux du serveur principal.
			 */
			idClient = serv.addClient(out);
		} catch (IOException e) {
		}

		/**
		 * On "thread" l'objet, la méthode héritée run() est alors appelée.
		 */
		t = new Thread(this);
		t.start();
	}

	/**
	 * Méthode héritée de l'interface Runnable et appelée lors de l'appel
	 * t.start().
	 */
	public void run() {
		String message = "";
		System.out.println("Nouveau client :" + idClient);

		try {
			/**
			 * Lecture du flux caractère par caractère. (Il est possible de
			 * faire mieux).
			 */
			char charCur[] = new char[1];

			/**
			 * Boucle sur les caractère reçus. Rappel: la fonction read() est
			 * bloquante d'où l'intérêt des threads.
			 */
			while (in.read(charCur, 0, 1) != -1) {
				/**
				 * Le caractère de fin de chaine est identifié par \u0000 ou \r
				 * ou \n.
				 */
				if (charCur[0] != '\u0000' && charCur[0] != '\n'
						&& charCur[0] != '\r')
					message += charCur[0]; /*
											 * Si ce n'est pas une fin de
											 * chaine, on concatène.
											 */

				else if (!message.equalsIgnoreCase("")) {
					if (charCur[0] == '\u0000')
						serv.sendAll(message, "" + charCur[0]);
					else
						serv.sendAll(message, "");
					message = "";
				}
			}
		} catch (Exception e) {
		} finally {
			/*
			 * finally se produira le plus souvent lors de la deconnexion d'un
			 * client
			 */
			try {
				System.out.println("Client déconnecté : " + idClient);
				serv.delClient(idClient);
				s.close();
			} catch (IOException e) {
			}
		}
	}
}
