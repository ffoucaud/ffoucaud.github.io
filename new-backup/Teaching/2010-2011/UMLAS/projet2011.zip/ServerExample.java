import java.net.*;
import java.io.*;
import java.util.*;

/**
 * Classe principale du serveur
 * 
 */
public class ServerExample {

	/**
	 * Tableau contenant une référence vers tous les clients connectés.
	 */
	private Vector<PrintWriter> clients = new Vector<PrintWriter>();
	private int port;

	/**
	 * Nombre de client connectés au serveur.
	 */
	private int nbClients = 0;

	/**
	 * Fonction (main) principale qui va boucler (écouter) pour attendres les
	 * connexions des clients
	 */
	public static void main(String args[]) {

		ServerExample serv = new ServerExample();

		try {
			/**
			 * Port d'écoute.
			 */
			serv.port = 18000;

			/**
			 * Création de la socket principale qui va se charger d'attendre les
			 * clients pour ensuite les dispatcher sur des thread particuliers.
			 */
			ServerSocket ss = new ServerSocket(serv.port);

			/**
			 * Le serveur attend les clients. Dès qu'un client se connecte, un
			 * thread est associé à ce client. Une socket est aussi attribuée à
			 * chacun d'entre eux.
			 */
			while (true)
				new HandleClientThread(ss.accept(), serv);

		} catch (Exception e) {
		}
	}

	/**
	 * Méthode d'envoi d'un message à tous les clients connectés au serveur.
	 * 
	 * @param message
	 *            message à envoyer.
	 * @param sLast
	 *            flag délimitant les fin du message.
	 */
	synchronized public void sendAll(String message, String sLast) {
		//TODO
		
		/**
		 * Déclaration du flux dans lequel écrire le message qui sera lu par les
		 * clients.
		 *
		 * Parcours de la liste des clients connectés.
		 *
		 * Récupération de la référence (flux) vers chaque client.

		 * Si non null, on écrit dedans.
		 */
	}

	/**
	 * Suppression (déconnexion) d'un client du serveur.
	 * 
	 * @param i
	 *            numéro du client.
	 */
	synchronized public void delClient(int i) {
		//TODO
	}

	/**
	 * Ajout (connexion) d'un client à la liste.
	 * 
	 * @param out
	 *            référence vers le client
	 * @return numéro du client
	 */
	synchronized public int addClient(PrintWriter out) {
		//TODO
	}

	/**
	 * @return retourne le nombre de client connectés au serveur.
	 */
	synchronized public int getNbClients() {
		//TODO
	}

}
